- Recomend�vel usar navegador Chrome ou Microsoft Edge
- Alguns bot�es n�o foram implementados neste prot�tipo, mas far�o parte do sistema final, como: adicionar usu�rio no canal, remover usu�rio no canal e bot�es de bate papo (tecla enter, emojis e anexo)

-Tarefas: 
1. Criar um novo canal de conversa
2. Realizar videoconferencia
3. Registar atividades/eventos no calend�rio virtual